const route= {
    '':'home-component',
    'signin':'signin-component',
    'signup':'signup-component',
    'dashboard':'dashboard-component',
    'game':'game-component',
    'pong': 'pong-game' ,
}

export default route